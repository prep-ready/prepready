export type Lang = 'pl' | 'en';
export const langs: Lang[] = ['pl', 'en'];

/** Adresy sekcji w każdym języku. Zmieniasz tu — zmienia się w całym serwisie. */
export const routes = {
  home:     { pl: '/pl/',                    en: '/en/' },
  index:    { pl: '/pl/indeks/',             en: '/en/readiness-index/' },
  news:     { pl: '/pl/aktualnosci/',         en: '/en/news/' },
  guides:   { pl: '/pl/poradniki/',          en: '/en/guides/' },
  checklist:{ pl: '/pl/checklisty/plecak-72h/', en: '/en/checklists/72-hour-bag/' },
  gear:     { pl: '/pl/sprzet/',             en: '/en/gear/' },
  about:    { pl: '/pl/o-nas/',              en: '/en/about/' },
  earn:     { pl: '/pl/jak-zarabiamy/',      en: '/en/how-we-earn/' },
  partners: { pl: '/pl/wspolpraca/',         en: '/en/partners/' },
  /** Tylko PL — dane PSP dotyczą Polski. Pusty adres EN = link nie pokazuje się w wersji angielskiej. */
  shelters: { pl: '/pl/mapa-schronow/',      en: '' },
  /** Tylko PL — część prawna dotyczy Polski, PDF-y są po polsku. */
  targets:  { pl: '/pl/tarcze-strzeleckie/', en: '' },
  /** Tylko PL — przepisy budowlane dotyczą Polski. */
  shelterDiy: { pl: '/pl/schron/', en: '' },
} as const;
export type RouteKey = keyof typeof routes;

export const guideBase = { pl: '/pl/poradniki/', en: '/en/guides/' } as const;

export const clusters = {
  bag:          { pl: 'Plecak ewakuacyjny', en: 'Go-bags' },
  'water-food': { pl: 'Woda i żywność',     en: 'Water & food' },
  shelter:      { pl: 'Schron i ochrona',   en: 'Shelter' },
  blackout:     { pl: 'Blackout',           en: 'Blackouts' },
  evacuation:   { pl: 'Ewakuacja i łączność', en: 'Evacuation & comms' },
  'first-aid':  { pl: 'Pierwsza pomoc',     en: 'First aid' },
  law:          { pl: 'Prawo i bezpieczeństwo', en: 'Law & safety' },
} as const;

/** Krótki opis tematu — pokazywany na kafelku, dopóki nie ma w nim poradnika. */
export const clusterDesc = {
  bag:          { pl: 'Co spakować, ile to waży i gdzie trzymać plecak, żeby wyjść z domu w 5 minut.', en: 'What to pack, how much it weighs and where to keep it so you can leave in five minutes.' },
  'water-food': { pl: 'Ile wody i jedzenia na osobę, jak je przechowywać i rotować, żeby nic się nie zmarnowało.', en: 'How much water and food per person, and how to store and rotate it so nothing goes to waste.' },
  shelter:      { pl: 'Miejsce ukrycia w bloku i w domu, uszczelnianie pomieszczenia i co w nim trzymać.', en: 'Where to shelter in a flat or a house, how to seal a room and what to keep there.' },
  blackout:     { pl: 'Światło, ciepło, jedzenie i łączność, gdy przez kilka dni nie ma prądu.', en: 'Light, heat, food and communication when the power is out for days.' },
  evacuation:   { pl: 'Sygnały syren, alerty, plan kontaktu rodziny i trasy ewakuacji.', en: 'Sirens, alerts, a family contact plan and evacuation routes.' },
  'first-aid':  { pl: 'Apteczka domowa i ewakuacyjna, podstawy pierwszej pomocy i leki na zapas.', en: 'A home and go-bag first-aid kit, first-aid basics and spare medication.' },
  law:          { pl: 'Przepisy, pozwolenia i obowiązki obywatela na czas kryzysu.', en: 'Rules, permits and civic duties in a crisis.' },
} as const;

export const ui = {
  pl: {
    'site.tagline': 'Spokojne, oparte na danych przygotowanie na kryzys.',
    'nav.index': 'Indeks', 'nav.news': 'Aktualności', 'nav.guides': 'Poradniki', 'nav.checklist': 'Checklisty', 'nav.gear': 'Sprzęt', 'nav.shelters': 'Mapa schronów', 'nav.targets': 'Tarcze do druku', 'nav.shelterDiy': 'Schron DIY',
    'nav.menu': 'Menu',
    'cta.start': 'Zacznij od plecaka 72h',
    'sample': 'Dane przykładowe',
    'strip.updated': 'Indeks zaktualizowano',
    'strip.alerts': 'Aktualne ostrzeżenia IMGW dla Twojego regionu',
    'idx.eyebrow': 'Indeks gotowości · Polska',
    'idx.title': 'Jak bardzo trzeba się przygotować?',
    'idx.todo': 'Co zrobić przy tym poziomie',
    'idx.delta7': 'w 7 dni', 'idx.ago30': '30 dni temu',
    'idx.compEyebrow': '6 składowych · wagi i źródła jawne',
    'idx.compTitle': 'Z czego składa się dzisiejszy wynik',
    'idx.method': 'Metodologia →',
    'idx.weight': 'waga',
    'clock.text': '<strong>{s} sekund do północy.</strong> Zegar Zagłady Bulletin of the Atomic Scientists, ustawiony {d}, najbliżej w historii. Pokazujemy go jako kontekst; nie wchodzi do indeksu.',
    'news.eyebrow': 'Feed · Polska · źródła urzędowe i media, codziennie',
    'news.title': 'Co się dzieje i co to znaczy dla Ciebie',
    'news.forYou': 'Dla Ciebie',
    'news.official': 'źródło urzędowe', 'news.media': 'doniesienia medialne, niezweryfikowane', 'strip.news': 'Aktualności',
    'news.all': 'Wszystko', 'news.weather': 'Pogoda i żywioły', 'news.energy': 'Energia', 'news.security': 'Bezpieczeństwo', 'news.health': 'Zdrowie',
    'news.more': 'Wszystkie aktualności →',
    'sev.1': 'info', 'sev.2': 'uwaga', 'sev.3': 'ważne', 'sev.4': 'pilne',
    'nl.eyebrow': 'Newsletter · co piątek', 'nl.title': 'Raport gotowości w 3 minuty',
    'nl.body': 'Zmiana indeksu, 3 najważniejsze wydarzenia tygodnia i jedno zadanie do zrobienia w domu. Alert tylko przy skoku o 10+ pkt.',
    'nl.btn': 'Zapisz mnie', 'nl.small': 'Zapisując się, zgadzasz się na newsletter PrepReady. Bez spamu, wypiszesz się jednym kliknięciem.', 'nl.placeholder': 'twoj@email.pl',
    'nl.pending': 'Zapis ruszy po podłączeniu narzędzia do newslettera.',
    'nl.ok': 'Dzięki! Jesteś na liście. Pierwszy raport w najbliższy piątek.', 'nl.err': 'Nie udało się zapisać. Spróbuj ponownie za chwilę.',
    'src.title': 'Monitorowane źródła',
    'start.eyebrow': 'Zacznij tutaj · po kolei', 'start.title': 'Trzy kroki na pierwszy weekend',
    'cl.eyebrow': 'Checklista interaktywna · zapis w przeglądarce', 'cl.title': 'Plecak ewakuacyjny na 72 godziny',
    'cl.sub': 'Lista oparta na „Poradniku bezpieczeństwa” MSWiA. Zaznacz, co już masz. Przy brakach podpowiadamy sprawdzony sprzęt.',
    'cl.reset': 'Wyczyść', 'cl.pick': 'Polecamy →', 'cl.picksTitle': 'Najczęstsze braki · nasze typy', 'cl.view': 'Sprawdź',
    'aff.disclose': 'Linki są partnerskie: jeśli coś kupisz, możemy dostać prowizję, a cena się dla Ciebie nie zmienia. Tych modeli nie testowaliśmy jeszcze osobiście. Wybraliśmy je na podstawie specyfikacji producentów. Ceny z 11.10.2026.',
    'aff.how': 'Jak działamy',
    'g.eyebrow': 'Poradniki · 6 tematów', 'g.title': 'Wiedza, która działa bez prądu i internetu', 'g.all': 'Wszystkie poradniki →',
    'g.min': 'min', 'g.reviewed': 'przegląd', 'g.soon': 'w przygotowaniu',
    'gear.eyebrow': 'Test redakcji', 'gear.title': 'Stacje zasilania na blackout',
    'gear.sub': 'W rankingach są tylko sprawdzone rzeczy. Mierzymy realną pojemność, czas ładowania i ile razy naładują telefon.',
    'gear.model': 'Model', 'gear.cap': 'Pojemność zmierzona (Wh)', 'gear.charge': 'Ładowanie 0–100% (h)', 'gear.phone': 'Ładowań telefonu', 'gear.score': 'Ocena', 'gear.price': 'Cena (zł)',
    'art.by': 'Autor', 'art.reviewedBy': 'Konsultacja', 'art.reviewed': 'Ostatni przegląd', 'art.sources': 'Źródła', 'art.faq': 'Najczęstsze pytania', 'art.toc': 'W tym poradniku',
    'art.disclaimer': 'Poradnik ma charakter edukacyjny. W sytuacji zagrożenia stosuj się do komunikatów RCB, RSO i służb.',
    'f.c1': 'Serwis', 'f.c2': 'Zaufanie', 'f.c3': 'Ważne numery',
    'f.about': 'Spokojne, oparte na danych przygotowanie na kryzys. Indeks jest narzędziem edukacyjnym. W sytuacji zagrożenia obowiązują komunikaty RCB, RSO i służb.',
    'f.team': 'O nas i redakcja', 'f.earn': 'Jak działamy', 'f.partners': 'Dla producentów', 'f.method': 'Metodologia indeksu',
    'theme': 'Motyw', 'lang.switch': 'English',
  },
  en: {
    'site.tagline': 'Calm, data-driven crisis preparedness.',
    'nav.index': 'Index', 'nav.news': 'News', 'nav.guides': 'Guides', 'nav.checklist': 'Checklists', 'nav.gear': 'Gear', 'nav.shelters': 'Shelter map', 'nav.targets': 'Printable targets', 'nav.shelterDiy': 'DIY shelter',
    'nav.menu': 'Menu',
    'cta.start': 'Start with a 72-hour kit',
    'sample': 'Sample data',
    'strip.updated': 'Index updated',
    'strip.alerts': 'Current global disaster alerts (GDACS)',
    'idx.eyebrow': 'Readiness Index · Global',
    'idx.title': 'How prepared should you be right now?',
    'idx.todo': 'What to do at this level',
    'idx.delta7': 'in 7 days', 'idx.ago30': '30 days ago',
    'idx.compEyebrow': '6 components · open weights and sources',
    'idx.compTitle': "What today's score is made of",
    'idx.method': 'Methodology →',
    'idx.weight': 'weight',
    'clock.text': "<strong>{s} seconds to midnight.</strong> The Bulletin of the Atomic Scientists' Doomsday Clock, set on {d}, the closest ever. Shown as context; not part of the index.",
    'news.eyebrow': 'Feed · worldwide · official sources and media, daily',
    'news.title': "What's happening and what it means for you",
    'news.forYou': 'For you',
    'news.official': 'official source', 'news.media': 'media report, unverified', 'strip.news': 'News',
    'news.all': 'All', 'news.weather': 'Disasters', 'news.energy': 'Energy', 'news.security': 'Security', 'news.health': 'Health',
    'news.more': 'All news →',
    'sev.1': 'info', 'sev.2': 'watch', 'sev.3': 'important', 'sev.4': 'urgent',
    'nl.eyebrow': 'Newsletter · every Friday', 'nl.title': 'The Readiness Report in 3 minutes',
    'nl.body': "The index change, the week's 3 key events and one task to do at home. Alerts only on a 10+ point jump.",
    'nl.btn': 'Sign me up', 'nl.small': 'By signing up you agree to receive the PrepReady newsletter. No spam, one-click unsubscribe.', 'nl.placeholder': 'you@email.com',
    'nl.pending': 'Sign-up goes live once the newsletter tool is connected.',
    'nl.ok': "Thanks! You're on the list. The first report arrives this Friday.", 'nl.err': "Couldn't sign you up. Please try again in a moment.",
    'src.title': 'Sources we monitor',
    'start.eyebrow': 'Start here · in order', 'start.title': 'Three steps for your first weekend',
    'cl.eyebrow': 'Interactive checklist · saved in your browser', 'cl.title': '72-hour go-bag',
    'cl.sub': 'Based on Ready.gov and EU civil-protection guidance. Tick what you have and we suggest tested gear for the gaps.',
    'cl.reset': 'Clear', 'cl.pick': 'Our pick →', 'cl.picksTitle': 'Most common gaps · our picks', 'cl.view': 'View',
    'aff.disclose': 'Some links are affiliate links: if you buy, we may earn a commission at no extra cost to you. We picked these from manufacturer specs and have not tested every model ourselves.',
    'aff.how': 'How we work',
    'g.eyebrow': 'Guides · 6 topics', 'g.title': 'Knowledge that works without power or internet', 'g.all': 'All guides →',
    'g.min': 'min', 'g.reviewed': 'reviewed', 'g.soon': 'coming soon',
    'gear.eyebrow': 'Editors’ test', 'gear.title': 'Portable power stations for blackouts',
    'gear.sub': 'Only checked gear makes our rankings. We measure real capacity, charge time and how many phone charges you get.',
    'gear.model': 'Model', 'gear.cap': 'Measured capacity (Wh)', 'gear.charge': 'Charge 0–100% (h)', 'gear.phone': 'Phone charges', 'gear.score': 'Score', 'gear.price': 'Price (EUR)',
    'art.by': 'By', 'art.reviewedBy': 'Reviewed by', 'art.reviewed': 'Last reviewed', 'art.sources': 'Sources', 'art.faq': 'FAQ', 'art.toc': 'In this guide',
    'art.disclaimer': 'This guide is educational. In an emergency, follow official alerts and first responders.',
    'f.c1': 'Site', 'f.c2': 'Trust', 'f.c3': 'Key numbers',
    'f.about': 'Calm, data-driven crisis preparedness. The index is an educational tool. In an emergency, follow official alerts and first responders.',
    'f.team': 'About & editors', 'f.earn': 'How we work', 'f.partners': 'For manufacturers', 'f.method': 'Index methodology',
    'theme': 'Theme', 'lang.switch': 'Polski',
  },
} as const;

export type UIKey = keyof typeof ui.pl;
export function t(lang: Lang, key: UIKey, vars: Record<string, string | number> = {}) {
  let s: string = ui[lang][key] ?? ui.pl[key];
  for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
  return s;
}

export function fmtDate(d: Date | string, lang: Lang, opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' }) {
  return new Date(d).toLocaleDateString(lang === 'pl' ? 'pl-PL' : 'en-GB', opts);
}
export const num = (n: number, lang: Lang, o?: Intl.NumberFormatOptions) =>
  n.toLocaleString(lang === 'pl' ? 'pl-PL' : 'en-US', o);
